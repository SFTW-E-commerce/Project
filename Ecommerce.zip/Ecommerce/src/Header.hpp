#ifndef HEADER_HPP
#define HEADER_HPP

int connection_red();
int connection_postgre();

#endif
